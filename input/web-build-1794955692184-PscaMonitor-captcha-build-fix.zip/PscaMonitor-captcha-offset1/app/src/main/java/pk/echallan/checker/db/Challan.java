package pk.echallan.checker.db;

import androidx.room.Entity;
import androidx.room.Index;
import androidx.room.PrimaryKey;

@Entity(tableName = "challans",
        indices = {@Index(value = {"vehicleId", "challanNo"}, unique = true), @Index("vehicleId")})
public class Challan {
    @PrimaryKey(autoGenerate = true) public long id;
    public long vehicleId;
    public String challanNo;
    public String plateNo;
    public long amount;
    public String violationType;
    public String location;
    public String violationDate;
    public String dueDate;
    public String status;
    public String details;
    public String evidenceUrl;
    public long firstSeenAt;
    public long lastSeenAt;
}
