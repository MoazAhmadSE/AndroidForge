package pk.echallan.checker.notify;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import androidx.core.app.NotificationCompat;
import pk.echallan.checker.R;
import pk.echallan.checker.VehicleDetailActivity;
import pk.echallan.checker.VerificationActivity;
import pk.echallan.checker.db.Challan;
import pk.echallan.checker.db.Vehicle;

public final class Notifier {
    public static final String CH_CHALLAN = "challan_updates";
    public static final String CH_VERIFY = "verification_required";
    public static final String CH_FAIL = "check_failures";
    public static final String CH_RUNNING = "monitoring";
    public static final int NOTIF_RUNNING = 9000;

    private static int id(String key) { return key.hashCode() & 0x7fffffff; }

    private static void post(Context c, String channel, int id, String title, String body, PendingIntent pi) {
        Notification n = new NotificationCompat.Builder(c, channel)
                .setSmallIcon(R.drawable.ic_launcher)
                .setContentTitle(title)
                .setContentText(body)
                .setStyle(new NotificationCompat.BigTextStyle().bigText(body))
                .setAutoCancel(true)
                .setContentIntent(pi)
                .build();
        NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm != null) nm.notify(id, n);
    }

    private static PendingIntent detailIntent(Context c, long vehicleId) {
        Intent i = new Intent(c, VehicleDetailActivity.class);
        i.putExtra("vehicleId", vehicleId);
        i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        return PendingIntent.getActivity(c, (int) vehicleId, i,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    public static void newChallan(Context c, Vehicle v, Challan ch) {
        String body = "Vehicle: " + v.plateNo
                + "\nChallan: " + ch.challanNo
                + "\nFine: Rs. " + ch.amount
                + "\nStatus: " + ch.status;
        post(c, CH_CHALLAN, id("NEW-" + v.id + "-" + ch.challanNo),
                "NEW CHALLAN DETECTED", body, detailIntent(c, v.id));
    }

    public static void paymentUpdated(Context c, Vehicle v, Challan ch) {
        String body = "Vehicle: " + v.plateNo
                + "\nChallan: " + ch.challanNo
                + "\nStatus: " + ch.status;
        post(c, CH_CHALLAN, id("PAID-" + v.id + "-" + ch.challanNo),
                "PAYMENT STATUS UPDATED", body, detailIntent(c, v.id));
    }

    public static void amountChanged(Context c, Vehicle v, Challan ch, long oldAmount) {
        String body = "Vehicle: " + v.plateNo
                + "\nChallan: " + ch.challanNo
                + "\nFine changed: Rs. " + oldAmount + " to Rs. " + ch.amount;
        post(c, CH_CHALLAN, id("AMT-" + v.id + "-" + ch.challanNo),
                "CHALLAN UPDATED", body, detailIntent(c, v.id));
    }

    public static void verificationRequired(Context c, Vehicle v) {
        Intent i = new Intent(c, VerificationActivity.class);
        i.putExtra("vehicleId", v.id);
        i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent pi = PendingIntent.getActivity(c, (int) v.id, i,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        post(c, CH_VERIFY, id("VER-" + v.id),
                "VERIFICATION REQUIRED",
                "Vehicle: " + v.plateNo + "\nPSCA requires additional verification. Tap to continue.",
                pi);
    }

    public static void checkFailed(Context c, Vehicle v, String reason) {
        post(c, CH_FAIL, id("FAIL-" + v.id),
                "CHECK FAILED",
                "Vehicle: " + v.plateNo + "\nReason: " + reason,
                detailIntent(c, v.id));
    }
}
