package pk.echallan.checker.db;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;
import java.util.List;

@Dao public interface VehicleDao {
    @Insert long insert(Vehicle v);
    @Update void update(Vehicle v);
    @Delete void delete(Vehicle v);

    @Query("SELECT * FROM vehicles ORDER BY plateNo") List<Vehicle> all();
    @Query("SELECT * FROM vehicles WHERE plateNo=:p LIMIT 1") Vehicle byPlate(String p);
    @Query("SELECT * FROM vehicles WHERE id=:id") Vehicle byId(long id);
    @Query("SELECT * FROM vehicles WHERE monitoringEnabled=1 ORDER BY lastAttemptAt ASC")
    List<Vehicle> enabledOrdered();

    @Query("UPDATE vehicles SET lastAttemptAt=:t WHERE id=:id")
    void markAttempt(long id, long t);

    @Query("UPDATE vehicles SET lastSuccessAt=:t,lastState=:s,lastReason=:r WHERE id=:id")
    void markResult(long id, long t, String s, String r);

    @Query("UPDATE vehicles SET monitoringEnabled=:e WHERE id=:id")
    void setEnabled(long id, boolean e);

    @Query("UPDATE vehicles SET unpaidCount=:c,outstanding=:o WHERE id=:id")
    void setTotals(long id, int c, long o);
}
