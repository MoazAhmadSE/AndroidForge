package pk.echallan.checker.db;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;
import java.util.List;

@Dao public interface ChallanDao {
    @Insert long insert(Challan c);
    @Update void update(Challan c);

    @Query("SELECT * FROM challans WHERE vehicleId=:v ORDER BY firstSeenAt DESC")
    List<Challan> byVehicle(long v);

    @Query("SELECT * FROM challans WHERE vehicleId=:v AND challanNo=:n LIMIT 1")
    Challan find(long v, String n);

    @Query("SELECT * FROM challans ORDER BY firstSeenAt DESC LIMIT 500")
    List<Challan> recent();

    @Query("SELECT COUNT(*) FROM challans WHERE vehicleId=:v AND status='UNPAID'")
    int unpaidCount(long v);

    @Query("SELECT IFNULL(SUM(amount),0) FROM challans WHERE vehicleId=:v AND status='UNPAID'")
    long outstanding(long v);
}
