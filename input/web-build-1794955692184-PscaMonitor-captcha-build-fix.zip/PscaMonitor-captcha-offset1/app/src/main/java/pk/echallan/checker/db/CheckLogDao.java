package pk.echallan.checker.db;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;
import java.util.List;

@Dao public interface CheckLogDao {
    @Insert void insert(CheckLog log);
    @Query("SELECT * FROM checks WHERE vehicleId=:v ORDER BY at DESC LIMIT 50")
    List<CheckLog> recentForVehicle(long v);
    @Query("SELECT * FROM checks ORDER BY at DESC LIMIT 200")
    List<CheckLog> recent();
}
