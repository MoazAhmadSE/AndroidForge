package pk.echallan.checker.monitor;

import android.app.Notification;
import android.content.Context;
import android.content.pm.ServiceInfo;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import androidx.annotation.NonNull;
import androidx.core.app.NotificationCompat;
import androidx.work.ForegroundInfo;
import androidx.work.Worker;
import androidx.work.WorkerParameters;
import java.util.List;
import pk.echallan.checker.R;
import pk.echallan.checker.db.AppDatabase;
import pk.echallan.checker.db.CheckLog;
import pk.echallan.checker.db.Challan;
import pk.echallan.checker.db.Vehicle;
import pk.echallan.checker.notify.Notifier;
import pk.echallan.checker.security.Crypto;

public class CheckQueueWorker extends Worker {

    public CheckQueueWorker(@NonNull Context ctx, @NonNull WorkerParameters p) { super(ctx, p); }

    @NonNull @Override public Result doWork() {
        Context ctx = getApplicationContext();
        try {
            Notification n = buildFg();
            setForegroundAsync(new ForegroundInfo(
                    Notifier.NOTIF_RUNNING, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC));
        } catch (Throwable ignored) { }

        AppDatabase db = AppDatabase.get(ctx);
        List<Vehicle> queue = db.vehicleDao().enabledOrdered();
        if (queue.isEmpty()) return Result.success();

        for (int i = 0; i < queue.size(); i++) {
            if (!online(ctx)) return Result.retry();
            Vehicle v = queue.get(i);
            long now = System.currentTimeMillis();
            db.vehicleDao().markAttempt(v.id, now);

            String cnic = Crypto.decrypt(v.cnicEnc);
            if (cnic == null || cnic.length() != 13) {
                record(db, v, "INVALID_CNIC", "Cannot decrypt CNIC");
                db.vehicleDao().markResult(v.id, now, "INVALID_CNIC", "CNIC unavailable");
                continue;
            }

            final Object lock = new Object();
            final PscaWebAutomation.Result[] holder = new PscaWebAutomation.Result[1];
            PscaWebAutomation.runBlocking(ctx, v.plateNo, cnic, 160_000L, r -> {
                synchronized (lock) { holder[0] = r; lock.notifyAll(); }
            });
            synchronized (lock) {
                while (holder[0] == null) {
                    try { lock.wait(170_000L); } catch (InterruptedException e) { break; }
                    if (holder[0] == null) break;
                }
            }
            PscaWebAutomation.Result r = holder[0];
            if (r == null) {
                record(db, v, "TIMEOUT", "No result from automation");
                db.vehicleDao().markResult(v.id, now, "TIMEOUT", "Automation timeout");
                Notifier.checkFailed(ctx, v, "Automation timeout");
                continue;
            }

            switch (r.state) {
                case PscaWebAutomation.STATE_OK: {
                    java.util.List<Challan> parsed = new java.util.ArrayList<>();
                    if (r.challans != null) for (org.json.JSONObject o : r.challans) {
                        Challan ch = ResultParser.toChallan(v.id, v.plateNo, o);
                        if (ch != null) parsed.add(ch);
                    }
                    ChangeDetector.apply(db, ctx, v, parsed);
                    long t = System.currentTimeMillis();
                    db.vehicleDao().markResult(v.id, t, "OK", null);
                    record(db, v, "OK", parsed.size() + " challans parsed");
                    break;
                }
                case PscaWebAutomation.STATE_EMPTY: {
                    long t = System.currentTimeMillis();
                    db.vehicleDao().markResult(v.id, t, "EMPTY", "No challans found");
                    int cnt = db.challanDao().unpaidCount(v.id);
                    long out = db.challanDao().outstanding(v.id);
                    db.vehicleDao().setTotals(v.id, cnt, out);
                    record(db, v, "EMPTY", "No challans found");
                    break;
                }
                case PscaWebAutomation.STATE_VERIFICATION: {
                    db.vehicleDao().markResult(v.id, now, "VERIFICATION_REQUIRED", r.reason);
                    record(db, v, "VERIFICATION_REQUIRED", r.reason);
                    Notifier.verificationRequired(ctx, v);
                    break;
                }
                case PscaWebAutomation.STATE_NETWORK: {
                    db.vehicleDao().markResult(v.id, now, "NETWORK_ERROR", r.reason);
                    record(db, v, "NETWORK_ERROR", r.reason);
                    Notifier.checkFailed(ctx, v, r.reason == null ? "Network error" : r.reason);
                    break;
                }
                default: {
                    db.vehicleDao().markResult(v.id, now, "PARSE_ERROR", r.reason);
                    record(db, v, "PARSE_ERROR", r.reason);
                    Notifier.checkFailed(ctx, v, r.reason == null ? "Could not read results" : r.reason);
                }
            }

            if (i < queue.size() - 1) {
                try { Thread.sleep(20_000L + (long)(Math.random() * 20_000L)); }
                catch (InterruptedException ignored) {}
            }
        }
        return Result.success();
    }

    private void record(AppDatabase db, Vehicle v, String state, String reason) {
        CheckLog l = new CheckLog();
        l.vehicleId = v.id; l.at = System.currentTimeMillis();
        l.state = state; l.reason = reason;
        db.checkLogDao().insert(l);
    }

    private Notification buildFg() {
        return new NotificationCompat.Builder(getApplicationContext(), Notifier.CH_RUNNING)
                .setSmallIcon(R.drawable.ic_launcher)
                .setContentTitle("PSCA Monitor")
                .setContentText("Checking saved vehicles...")
                .setOngoing(true).setOnlyAlertOnce(true).build();
    }

    private static boolean online(Context c) {
        ConnectivityManager cm = (ConnectivityManager) c.getSystemService(Context.CONNECTIVITY_SERVICE);
        if (cm == null) return true;
        NetworkInfo n = cm.getActiveNetworkInfo();
        return n != null && n.isConnected();
    }
}
