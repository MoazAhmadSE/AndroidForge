package pk.echallan.checker;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.util.List;
import pk.echallan.checker.db.AppDatabase;
import pk.echallan.checker.db.Challan;
import pk.echallan.checker.db.Vehicle;
import pk.echallan.checker.monitor.MonitoringScheduler;

public class VehicleDetailActivity extends AppCompatActivity {
    private long vehicleId;
    private LinearLayout body;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        vehicleId = getIntent().getLongExtra("vehicleId", -1);
        if (vehicleId <= 0) { finish(); return; }
        ScrollView sc = new ScrollView(this);
        body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);
        int p = (int)(16 * getResources().getDisplayMetrics().density);
        body.setPadding(p, p, p, p);
        sc.addView(body);
        setContentView(sc);
        render();
    }

    @Override protected void onResume() { super.onResume(); render(); }

    private void render() {
        AppDatabase.io().execute(() -> {
            AppDatabase db = AppDatabase.get(this);
            Vehicle v = db.vehicleDao().byId(vehicleId);
            List<Challan> chs = db.challanDao().byVehicle(vehicleId);
            runOnUiThread(() -> draw(v, chs));
        });
    }

    private void draw(Vehicle v, List<Challan> chs) {
        if (v == null) { finish(); return; }
        body.removeAllViews();
        add("Plate: " + v.plateNo);
        if (v.nickname != null) add("Nickname: " + v.nickname);
        add("CNIC: *************");
        add("State: " + v.lastState + (v.lastReason != null ? "  (" + v.lastReason + ")" : ""));
        add("Unpaid: " + v.unpaidCount + "   Outstanding: Rs. " + v.outstanding);
        add("Last success: " + fmt(v.lastSuccessAt));

        Switch mon = new Switch(this);
        mon.setText("Monitoring enabled");
        mon.setChecked(v.monitoringEnabled);
        mon.setOnCheckedChangeListener((b, checked) -> AppDatabase.io().execute(() -> {
            AppDatabase db = AppDatabase.get(this);
            db.vehicleDao().setEnabled(v.id, checked);
            MonitoringScheduler.schedule(this);
        }));
        body.addView(mon);

        Button check = new Button(this); check.setText("Check now");
        check.setOnClickListener(x -> { MonitoringScheduler.runNow(this); toast("Queue started"); });
        Button verify = new Button(this); verify.setText("Open verification page");
        verify.setOnClickListener(x -> {
            Intent i = new Intent(this, VerificationActivity.class);
            i.putExtra("vehicleId", v.id);
            startActivity(i);
        });
        Button del = new Button(this); del.setText("Delete vehicle");
        del.setOnClickListener(x -> AppDatabase.io().execute(() -> {
            AppDatabase db = AppDatabase.get(this);
            db.vehicleDao().delete(v);
            runOnUiThread(this::finish);
        }));
        body.addView(check); body.addView(verify); body.addView(del);

        add("\nChallan history:");
        if (chs.isEmpty()) add("(none recorded)");
        for (Challan c : chs) {
            TextView t = new TextView(this);
            t.setText("#" + c.challanNo + "  Rs. " + c.amount + "  " + c.status
                    + (c.violationType != null ? "\n" + c.violationType : "")
                    + (c.violationDate != null ? "  " + c.violationDate : ""));
            t.setPadding(0, 8, 0, 8);
            body.addView(t);
        }
    }

    private void add(String s) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setPadding(0, 6, 0, 6);
        body.addView(t);
    }

    private String fmt(long t) {
        if (t <= 0) return "never";
        return android.text.format.DateFormat.format("yyyy-MM-dd HH:mm", t).toString();
    }
    private void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_SHORT).show(); }
}
