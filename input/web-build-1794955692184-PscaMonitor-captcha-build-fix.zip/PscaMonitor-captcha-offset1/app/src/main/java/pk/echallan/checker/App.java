package pk.echallan.checker;

import android.app.Application;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.os.Build;

import pk.echallan.checker.monitor.MonitoringScheduler;
import pk.echallan.checker.notify.Notifier;

public class App extends Application {
    @Override public void onCreate() {
        super.onCreate();
        createChannels();
        MonitoringScheduler.schedule(this);
    }

    private void createChannels() {
        if (Build.VERSION.SDK_INT < 26) return;
        NotificationManager nm = getSystemService(NotificationManager.class);
        nm.createNotificationChannel(new NotificationChannel(
                Notifier.CH_CHALLAN, "Challan updates", NotificationManager.IMPORTANCE_DEFAULT));
        nm.createNotificationChannel(new NotificationChannel(
                Notifier.CH_VERIFY, "Verification required", NotificationManager.IMPORTANCE_HIGH));
        nm.createNotificationChannel(new NotificationChannel(
                Notifier.CH_FAIL, "Check failures", NotificationManager.IMPORTANCE_LOW));
        nm.createNotificationChannel(new NotificationChannel(
                Notifier.CH_RUNNING, "Monitoring", NotificationManager.IMPORTANCE_LOW));
    }
}
