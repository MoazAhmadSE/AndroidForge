package pk.echallan.checker;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import java.util.List;
import pk.echallan.checker.db.AppDatabase;
import pk.echallan.checker.db.Vehicle;
import pk.echallan.checker.monitor.MonitoringScheduler;

public class MainActivity extends AppCompatActivity {
    private LinearLayout list;
    private TextView summary;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.POST_NOTIFICATIONS}, 10);
        }
        setContentView(buildUi());
        MonitoringScheduler.schedule(this);
    }

    @Override protected void onResume() { super.onResume(); refresh(); }

    private View buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16), dp(16), dp(16), dp(16));

        TextView title = new TextView(this);
        title.setText("PSCA E-Challan Auto Monitor");
        title.setTextSize(20); title.setTypeface(null, Typeface.BOLD);
        root.addView(title);

        summary = new TextView(this);
        summary.setPadding(0, dp(8), 0, dp(12));
        root.addView(summary);

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        Button add = new Button(this); add.setText("Add vehicle");
        add.setOnClickListener(v -> startActivity(new Intent(this, AddVehicleActivity.class)));
        Button run = new Button(this); run.setText("Check now");
        run.setOnClickListener(v -> { MonitoringScheduler.runNow(this); toast("Queue started"); });
        Button batt = new Button(this); batt.setText("Battery");
        batt.setOnClickListener(v -> openBattery());
        row.addView(add, lp()); row.addView(run, lp()); row.addView(batt, lp());
        root.addView(row);

        ScrollView sc = new ScrollView(this);
        list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        sc.addView(list);
        root.addView(sc, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));
        return root;
    }

    private void refresh() {
        AppDatabase.io().execute(() -> {
            AppDatabase db = AppDatabase.get(this);
            List<Vehicle> all = db.vehicleDao().all();
            int totalUnpaid = 0; long totalOut = 0;
            for (Vehicle v : all) { totalUnpaid += v.unpaidCount; totalOut += v.outstanding; }
            final int unpaid = totalUnpaid; final long out = totalOut;
            runOnUiThread(() -> {
                summary.setText("Vehicles: " + all.size()
                        + "   Unpaid: " + unpaid
                        + "   Outstanding: Rs. " + out);
                list.removeAllViews();
                for (Vehicle v : all) addRow(v);
            });
        });
    }

    private void addRow(Vehicle v) {
        LinearLayout r = new LinearLayout(this);
        r.setOrientation(LinearLayout.HORIZONTAL);
        r.setPadding(0, dp(10), 0, dp(10));

        View dot = new View(this);
        dot.setBackgroundColor(colorFor(v.lastState));
        r.addView(dot, new LinearLayout.LayoutParams(dp(12), dp(12)));

        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(dp(12), 0, 0, 0);

        TextView t1 = new TextView(this);
        t1.setText(v.plateNo + (v.nickname != null ? "  (" + v.nickname + ")" : ""));
        t1.setTypeface(null, Typeface.BOLD);
        TextView t2 = new TextView(this);
        t2.setText("Unpaid: " + v.unpaidCount + "   Rs. " + v.outstanding
                + "   State: " + v.lastState);
        t2.setTextSize(12);
        col.addView(t1); col.addView(t2);
        r.addView(col);

        r.setOnClickListener(view -> {
            Intent i = new Intent(this, VehicleDetailActivity.class);
            i.putExtra("vehicleId", v.id);
            startActivity(i);
        });
        list.addView(r);
    }

    private int colorFor(String state) {
        if (state == null) return Color.GRAY;
        switch (state) {
            case "OK":
            case "EMPTY": return Color.parseColor("#2E7D32");
            case "VERIFICATION_REQUIRED": return Color.parseColor("#F9A825");
            case "NETWORK_ERROR":
            case "PARSE_ERROR":
            case "TIMEOUT": return Color.parseColor("#EF6C00");
            default: return Color.GRAY;
        }
    }

    private void openBattery() {
        try {
            Intent i = new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS);
            i.setData(Uri.parse("package:" + getPackageName()));
            startActivity(i);
        } catch (Exception e) { toast("Open Settings -> Battery -> Unrestricted"); }
    }

    private LinearLayout.LayoutParams lp() {
        return new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
    }
    private int dp(int n) { return (int)(n * getResources().getDisplayMetrics().density); }
    private void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_SHORT).show(); }

    @Override public void onRequestPermissionsResult(int rc, @NonNull String[] p, @NonNull int[] g) {
        super.onRequestPermissionsResult(rc, p, g);
    }
}
