package pk.echallan.checker;

import android.os.Bundle;
import android.text.InputType;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import pk.echallan.checker.db.AppDatabase;
import pk.echallan.checker.db.Vehicle;
import pk.echallan.checker.monitor.MonitoringScheduler;
import pk.echallan.checker.security.Crypto;

public class AddVehicleActivity extends AppCompatActivity {
    private EditText plate, cnic, nick;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        int p = (int)(16 * getResources().getDisplayMetrics().density);
        root.setPadding(p, p, p, p);

        plate = new EditText(this);
        plate.setHint("Vehicle registration (e.g. ANN 7601)");
        plate.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS);

        cnic = new EditText(this);
        cnic.setHint("Owner CNIC (13 digits)");
        cnic.setInputType(InputType.TYPE_CLASS_NUMBER);
        cnic.setMaxLines(1);

        nick = new EditText(this);
        nick.setHint("Nickname (optional)");

        Button save = new Button(this);
        save.setText("Save");
        save.setOnClickListener(v -> save());

        root.addView(plate); root.addView(cnic); root.addView(nick); root.addView(save);
        setContentView(root);
    }

    private void save() {
        String pl = plate.getText().toString().trim().toUpperCase().replaceAll("\\s+", " ");
        String cn = cnic.getText().toString().trim();
        String nk = nick.getText().toString().trim();

        if (pl.length() < 4) { toast("Enter a valid plate number"); return; }
        if (!cn.matches("[0-9]{13}")) { toast("CNIC must be exactly 13 digits"); return; }

        AppDatabase.io().execute(() -> {
            AppDatabase db = AppDatabase.get(this);
            if (db.vehicleDao().byPlate(pl) != null) {
                runOnUiThread(() -> toast("Vehicle already exists"));
                return;
            }
            Vehicle v = new Vehicle();
            v.plateNo = pl;
            v.nickname = nk.isEmpty() ? null : nk;
            v.cnicEnc = Crypto.encrypt(cn);
            v.monitoringEnabled = true;
            v.createdAt = System.currentTimeMillis();
            v.lastState = "PENDING";
            db.vehicleDao().insert(v);
            MonitoringScheduler.schedule(this);
            MonitoringScheduler.runNow(this);
            runOnUiThread(() -> { toast("Saved. Queue started."); finish(); });
        });
    }

    private void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_SHORT).show(); }
}
