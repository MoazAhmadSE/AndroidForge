package pk.echallan.checker.monitor;

import android.content.Context;
import java.util.List;
import pk.echallan.checker.db.AppDatabase;
import pk.echallan.checker.db.Challan;
import pk.echallan.checker.db.Vehicle;
import pk.echallan.checker.notify.Notifier;

public final class ChangeDetector {

    public static void apply(AppDatabase db, Context ctx, Vehicle v, List<Challan> incoming) {
        for (Challan in : incoming) {
            Challan existing = db.challanDao().find(v.id, in.challanNo);
            if (existing == null) {
                db.challanDao().insert(in);
                Notifier.newChallan(ctx, v, in);
            } else {
                String oldStatus = existing.status;
                long oldAmount = existing.amount;
                existing.lastSeenAt = System.currentTimeMillis();
                existing.amount = in.amount;
                existing.status = in.status;
                existing.violationType = in.violationType != null ? in.violationType : existing.violationType;
                existing.location = in.location != null ? in.location : existing.location;
                existing.violationDate = in.violationDate != null ? in.violationDate : existing.violationDate;
                existing.dueDate = in.dueDate != null ? in.dueDate : existing.dueDate;
                existing.details = in.details != null ? in.details : existing.details;
                existing.evidenceUrl = in.evidenceUrl != null ? in.evidenceUrl : existing.evidenceUrl;
                db.challanDao().update(existing);

                if (!"PAID".equals(oldStatus) && "PAID".equals(in.status)) {
                    Notifier.paymentUpdated(ctx, v, existing);
                } else if (oldAmount != in.amount) {
                    Notifier.amountChanged(ctx, v, existing, oldAmount);
                }
            }
        }
        int cnt = db.challanDao().unpaidCount(v.id);
        long out = db.challanDao().outstanding(v.id);
        db.vehicleDao().setTotals(v.id, cnt, out);
    }
}
