package pk.echallan.checker;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

import pk.echallan.checker.monitor.MonitoringScheduler;

public class BootReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context, Intent intent) {
        if (Intent.ACTION_BOOT_COMPLETED.equals(intent.getAction())) {
            MonitoringScheduler.schedule(context);
        }
    }
}
