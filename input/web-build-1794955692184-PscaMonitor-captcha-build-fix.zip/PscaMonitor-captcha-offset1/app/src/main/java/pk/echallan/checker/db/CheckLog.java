package pk.echallan.checker.db;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "checks")
public class CheckLog {
    @PrimaryKey(autoGenerate = true) public long id;
    public long vehicleId;
    public long at;
    public String state;
    public String reason;
}
