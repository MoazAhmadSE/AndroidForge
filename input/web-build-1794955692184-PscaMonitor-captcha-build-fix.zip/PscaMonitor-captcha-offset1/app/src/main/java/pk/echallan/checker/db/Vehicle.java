package pk.echallan.checker.db;

import androidx.annotation.NonNull;
import androidx.room.Entity;
import androidx.room.Index;
import androidx.room.PrimaryKey;

@Entity(tableName = "vehicles", indices = {@Index(value = "plateNo", unique = true)})
public class Vehicle {
    @PrimaryKey(autoGenerate = true) public long id;
    @NonNull public String plateNo = "";
    public String cnicEnc;
    public String nickname;
    public boolean monitoringEnabled = true;
    public long createdAt;
    public long lastAttemptAt;
    public long lastSuccessAt;
    public String lastState = "PENDING";
    public String lastReason;
    public int unpaidCount;
    public long outstanding;
}
