package pk.echallan.checker.monitor;

import org.json.JSONArray;
import org.json.JSONObject;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Locale;
import java.util.Map;
import pk.echallan.checker.db.Challan;

public final class ResultParser {

    public static Challan toChallan(long vehicleId, String plate, JSONObject item) {
        String no = pick(item, "challan no", "challan number", "challanno", "challan #", "challan");
        if (no == null || no.isEmpty()) {
            JSONArray cells = item.optJSONArray("__cells");
            if (cells != null) for (int i = 0; i < cells.length(); i++) {
                String c = cells.optString(i, "");
                if (c.matches("[0-9]{6,}")) { no = c; break; }
            }
        }
        if (no == null || no.isEmpty()) return null;

        Challan ch = new Challan();
        ch.vehicleId = vehicleId;
        ch.challanNo = no.trim();
        ch.plateNo = plate;
        ch.amount = parseAmount(pick(item, "amount", "fine", "total"));
        ch.violationType = pick(item, "violation", "offence", "offense", "type");
        ch.location = pick(item, "location", "place", "address", "point");
        ch.violationDate = pick(item, "date", "time");
        ch.dueDate = pick(item, "due");
        String st = pick(item, "status", "payment");
        ch.status = classify(st);
        ch.details = pick(item, "detail", "description", "remark");
        ch.evidenceUrl = pick(item, "image", "evidence", "photo", "picture");
        long now = System.currentTimeMillis();
        ch.firstSeenAt = now; ch.lastSeenAt = now;
        return ch;
    }

    private static String classify(String s) {
        if (s == null) return "UNKNOWN";
        String t = s.toLowerCase(Locale.ROOT);
        if (t.contains("unpaid") || t.contains("pending") || t.contains("not paid")) return "UNPAID";
        if (t.contains("paid")) return "PAID";
        return "UNKNOWN";
    }

    private static long parseAmount(String s) {
        if (s == null) return 0L;
        StringBuilder digits = new StringBuilder();
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c >= '0' && c <= '9') digits.append(c);
        }
        if (digits.length() == 0) return 0L;
        try { return Long.parseLong(digits.toString()); } catch (Exception e) { return 0L; }
    }

    private static String pick(JSONObject o, String... needles) {
        Map<String, String> map = new HashMap<>();
        Iterator<String> it = o.keys();
        while (it.hasNext()) {
            String k = it.next();
            map.put(k.toLowerCase(Locale.ROOT), o.optString(k, ""));
        }
        for (String n : needles) {
            for (Map.Entry<String, String> e : map.entrySet()) {
                if (e.getKey().contains(n) && e.getValue() != null && !e.getValue().isEmpty()) {
                    return e.getValue().trim();
                }
            }
        }
        return null;
    }
}
