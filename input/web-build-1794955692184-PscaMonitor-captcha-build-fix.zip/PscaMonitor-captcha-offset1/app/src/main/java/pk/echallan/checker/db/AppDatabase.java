package pk.echallan.checker.db;

import android.content.Context;
import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

@Database(entities = {Vehicle.class, Challan.class, CheckLog.class}, version = 1, exportSchema = false)
public abstract class AppDatabase extends RoomDatabase {
    public abstract VehicleDao vehicleDao();
    public abstract ChallanDao challanDao();
    public abstract CheckLogDao checkLogDao();

    private static final ExecutorService IO = Executors.newSingleThreadExecutor();
    public static ExecutorService io() { return IO; }

    private static volatile AppDatabase INSTANCE;
    public static AppDatabase get(Context c) {
        if (INSTANCE == null) {
            synchronized (AppDatabase.class) {
                if (INSTANCE == null) {
                    INSTANCE = Room.databaseBuilder(
                            c.getApplicationContext(), AppDatabase.class, "psca.db")
                            .fallbackToDestructiveMigration().build();
                }
            }
        }
        return INSTANCE;
    }
}
