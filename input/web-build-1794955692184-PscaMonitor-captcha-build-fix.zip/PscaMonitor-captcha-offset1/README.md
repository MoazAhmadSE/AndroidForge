# PSCA E-Challan Auto Monitor

Package: `pk.echallan.checker`. Java + Room + WorkManager + WebView.

## Build

Open the folder in Android Studio (Hedgehog or newer). On first sync Android Studio
will download the Gradle wrapper JAR automatically. Then:

    ./gradlew assembleDebug
    # APK: app/build/outputs/apk/debug/app-debug.apk

If you have a system `gradle` and prefer CLI:

    cd PscaMonitor
    gradle wrapper --gradle-version 8.2
    ./gradlew assembleDebug

## Usage

1. Launch the app. Grant the notification permission.
2. Tap **Add vehicle**. Enter plate (e.g. `ANN 7601`) and 13-digit CNIC.
3. The app schedules a 15-minute periodic check via WorkManager and runs one cycle immediately.
4. When PSCA requires an interactive CAPTCHA, you get a "VERIFICATION REQUIRED"
   notification. Tap it. A visible page opens. Complete the check. The app submits
   and stores the results.

## Architecture

- `db/*` — Room entities/DAOs for vehicles, challans, checks.
- `security/Crypto` — AES-GCM via Android Keystore. CNICs are never stored plaintext.
- `monitor/MonitoringScheduler` — WorkManager periodic (15 min) + one-time "run now".
- `monitor/CheckQueueWorker` — sequential vehicle queue, per-vehicle state transitions,
  notifications, and polite 20-40s spacing between vehicles.
- `monitor/PscaWebAutomation` — background WebView that loads PSCA, fills the form,
  detects the Cap widget via shadow DOM, tries one programmatic `solve()`, submits
  when a token exists, and parses results.
- `monitor/ResultParser` — header-driven table parser. Never invents challan data.
- `monitor/ChangeDetector` — compares challan sets, fires new/paid/amount events.
- `notify/Notifier` — 4 channels, event dedupe by `(vehicleId, challanNo, event)`.

## Honest limitations

1. **No public PSCA API exists.** All integration is DOM-level. If the site changes,
   the parser fails loudly (`PARSE_ERROR`) instead of returning "no challans".
2. **Cap CAPTCHA is interactive.** If the PSCA site-key requires genuine human
   interaction, `solve()` rejects with `no_interaction` and the app correctly
   transitions to `VERIFICATION_REQUIRED` and shows a visible page. This is the
   legitimate maximum; it is not a bypass.
3. **15-minute interval is a minimum**, subject to Doze and OEM battery restrictions.
   The app offers a battery-optimization shortcut.
4. **Anti-forgery cookie pairing.** The app submits via the live WebView form, so
   the `__RequestVerificationToken` cookie is handled by the browser. A native POST
   path would also require copying the cookie via `CookieManager`.
5. **Live CAPTCHA behaviour was not validated against PSCA in this build.**
   Deterministic layers (DB, queue, parser, change detection, notification dedupe)
   are unit-testable offline. Cap behaviour must be tested on a real device.
