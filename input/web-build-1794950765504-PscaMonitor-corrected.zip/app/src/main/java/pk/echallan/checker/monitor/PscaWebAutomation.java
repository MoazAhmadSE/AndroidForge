package pk.echallan.checker.monitor;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.webkit.CookieManager;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import org.json.JSONArray;
import org.json.JSONObject;
import org.json.JSONTokener;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;

public final class PscaWebAutomation {

    public static final String STATE_OK = "OK";
    public static final String STATE_EMPTY = "EMPTY";
    public static final String STATE_VERIFICATION = "VERIFICATION_REQUIRED";
    public static final String STATE_NETWORK = "NETWORK_ERROR";
    public static final String STATE_PARSE = "PARSE_ERROR";
    public static final String STATE_TIMEOUT = "TIMEOUT";

    public static class Result {
        public final String state; public final String reason;
        public final List<JSONObject> challans;
        public Result(String s, String r, List<JSONObject> c) { state=s; reason=r; challans=c; }
    }
    public interface Callback { void onResult(Result r); }

    private static final String HOME = "https://echallan.psca.gop.pk/";

    public static void runBlocking(final Context appCtx, final String plate, final String cnic,
                                   final long timeoutMs, final Callback cb) {
        final CountDownLatch latch = new CountDownLatch(1);
        final AtomicBoolean finished = new AtomicBoolean(false);
        final Handler main = new Handler(Looper.getMainLooper());

        main.post(() -> start(appCtx, plate, cnic, r -> {
            if (finished.compareAndSet(false, true)) { cb.onResult(r); latch.countDown(); }
        }));

        try { latch.await(timeoutMs, TimeUnit.MILLISECONDS); } catch (InterruptedException ignored) {}
        if (finished.compareAndSet(false, true)) cb.onResult(new Result(STATE_TIMEOUT, "Automation timeout", null));
    }

    private static void start(Context ctx, String plate, String cnic, Callback cb) {
        final WebView wv;
        try { wv = new WebView(ctx); }
        catch (Throwable t) { cb.onResult(new Result(STATE_PARSE, "WebView unavailable", null)); return; }

        WebSettings s = wv.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setUseWideViewPort(true);
        s.setLoadWithOverviewMode(true);
        CookieManager.getInstance().setAcceptCookie(true);

        final long startAt = System.currentTimeMillis();
        final long deadline = startAt + 145_000L;
        final boolean[] submitted = {false};
        final boolean[] solveTried = {false};
        final Runnable[] pollRef = new Runnable[1];

        final Runnable poll = new Runnable() {
            @Override public void run() {
                if (System.currentTimeMillis() > deadline) {
                    cb.onResult(new Result(STATE_TIMEOUT, "Automation timeout", null)); return;
                }
                wv.evaluateJavascript(
                        "(function(){if(!window.__psca)return 'null';return JSON.stringify(window.__psca);})()",
                        raw -> {
                            String json = unwrap(raw);
                            if (json != null) {
                                try {
                                    JSONObject o = new JSONObject(json);
                                    String st = o.optString("state", "");
                                    if ("token_ready".equals(st) && !submitted[0]) {
                                        submitted[0] = true;
                                        wv.evaluateJavascript(JS_SUBMIT, null);
                                    } else if ("awaiting_cap".equals(st) && !solveTried[0]
                                            && System.currentTimeMillis() - startAt > 12_000L) {
                                        solveTried[0] = true;
                                        wv.evaluateJavascript(JS_SOLVE, null);
                                    } else if ("cap_error".equals(st)) {
                                        cb.onResult(new Result(STATE_VERIFICATION, "CAPTCHA reported error", null));
                                        return;
                                    } else if ("results".equals(st)) {
                                        JSONObject d = o.optJSONObject("data");
                                        if (d != null) {
                                            List<JSONObject> items = new ArrayList<>();
                                            JSONArray arr = d.optJSONArray("items");
                                            if (arr != null) for (int i = 0; i < arr.length(); i++) {
                                                JSONObject it = arr.optJSONObject(i);
                                                if (it != null) items.add(it);
                                            }
                                            boolean empty = d.optBoolean("empty", false);
                                            cb.onResult(new Result(empty ? STATE_EMPTY : STATE_OK,
                                                    empty ? "No challans found" : null, items));
                                            return;
                                        }
                                    }
                                } catch (Exception ignored) {}
                            }
                            new Handler(Looper.getMainLooper()).postDelayed(this, 900);
                        });
            }
        };
        pollRef[0] = poll;

        wv.setWebViewClient(new WebViewClient() {
            @Override public void onPageFinished(WebView view, String url) {
                view.evaluateJavascript(
                        "window.__psca_plate=" + JSONObject.quote(plate)
                        + ";window.__psca_cnic=" + JSONObject.quote(cnic) + ";", null);
                view.evaluateJavascript(JS_BOOT, null);
                view.evaluateJavascript(JS_PARSE, null);
                new Handler(Looper.getMainLooper()).removeCallbacks(pollRef[0]);
                new Handler(Looper.getMainLooper()).post(pollRef[0]);
            }
            @Override public void onReceivedError(WebView view, int code, String desc, String url) {
                cb.onResult(new Result(STATE_NETWORK, desc, null));
            }
        });

        wv.loadUrl(HOME);
    }

    private static String unwrap(String raw) {
        if (raw == null) return null;
        String t = raw.trim();
        if (t.isEmpty() || "null".equals(t) || "undefined".equals(t)) return null;
        try {
            Object v = new JSONTokener(t).nextValue();
            return v instanceof String ? (String) v : v.toString();
        } catch (Exception e) { return null; }
    }

    private static final String JS_BOOT = """
(function(){
  window.__psca = window.__psca || {};
  window.__psca.state = 'loading';
  window.__psca.token = null;
  window.__psca.data = null;
  function q(s){ return document.querySelector(s); }
  var plate = q('input[name="PlateNo"],#PlateNo,input[id*="Plate" i],input[placeholder*="Plate" i],input[placeholder*="Vehicle" i],input[placeholder*="Registration" i]');
  var cnic  = q('input[name="OwnerCNIC"],#OwnerCNIC,#CNIC,input[name="cnic"],input[id*="CNIC" i],input[placeholder*="CNIC" i]');
  if (plate && cnic) {
    plate.value = window.__psca_plate || '';
    cnic.value  = window.__psca_cnic  || '';
    ['input','change','blur'].forEach(function(ev){
      plate.dispatchEvent(new Event(ev,{bubbles:true}));
      cnic.dispatchEvent(new Event(ev,{bubbles:true}));
    });
    window.__psca.state = 'form_filled';
  }
  var t0 = Date.now();
  var timer = setInterval(function(){
    var cap = q('cap-widget');
    if (cap) {
      var root = cap.shadowRoot;
      var w = root && root.querySelector('.captcha');
      var st = w && w.getAttribute('data-state');
      if (st === 'done') {
        var ti = cap.querySelector('input[name="cap-token"]');
        if (ti && ti.value) {
          window.__psca.token = ti.value;
          window.__psca.state = 'token_ready';
          clearInterval(timer);
          return;
        }
      }
      if (st === 'error' || (w && w.classList && w.classList.contains('invalid'))) {
        window.__psca.state = 'cap_error';
        clearInterval(timer);
        return;
      }
      if (window.__psca.state === 'form_filled') window.__psca.state = 'awaiting_cap';
    }
    if (Date.now() - t0 > 90000) clearInterval(timer);
  }, 700);
})();
""";

    private static final String JS_SOLVE = """
(function(){
  try {
    var c = document.querySelector('cap-widget');
    if (c && typeof c.solve === 'function') { c.solve(); }
  } catch (e) {}
})();
""";

    private static final String JS_SUBMIT = """
(function(){
  var t = document.querySelector('input[name="cap-token"]');
  if (!t || !t.value) { window.__psca.state = 'token_missing'; return; }
  var f = t.closest('form') || document.querySelector('form');
  if (!f) { window.__psca.state = 'form_missing'; return; }
  var b = f.querySelector('button[type="submit"],input[type="submit"],button.btn-primary');
  if (b) { b.click(); } else { f.submit(); }
  window.__psca.state = 'submitted';
})();
""";

    private static final String JS_PARSE = """
(function(){
  if (!window.__psca) window.__psca = {};
  if (window.__psca.data) return;
  var tables = document.querySelectorAll('table');
  var best = null, bestRows = 0;
  for (var i = 0; i < tables.length; i++) {
    var rs = tables[i].querySelectorAll('tbody tr');
    if (rs.length > bestRows) { best = tables[i]; bestRows = rs.length; }
  }
  if (best && bestRows > 0) {
    var headers = [];
    var ths = best.querySelectorAll('thead th');
    for (var j = 0; j < ths.length; j++) headers.push((ths[j].innerText || '').trim().toLowerCase());
    var items = [];
    var rows = best.querySelectorAll('tbody tr');
    for (var k = 0; k < rows.length; k++) {
      var tds = rows[k].querySelectorAll('td');
      if (tds.length < 3) continue;
      var o = {}; var cells = [];
      for (var m = 0; m < tds.length; m++) {
        var txt = (tds[m].innerText || '').trim();
        cells.push(txt);
        if (headers[m]) o[headers[m]] = txt;
      }
      o['__cells'] = cells;
      items.push(o);
    }
    window.__psca.data = {empty:false, items:items};
    window.__psca.state = 'results';
    return;
  }
  var body = ((document.body && document.body.innerText) || '').toLowerCase();
  if (body.indexOf('no record') >= 0 || body.indexOf('no challan') >= 0 || body.indexOf('not found') >= 0) {
    window.__psca.data = {empty:true, items:[]};
    window.__psca.state = 'results';
  }
})();
""";
}
