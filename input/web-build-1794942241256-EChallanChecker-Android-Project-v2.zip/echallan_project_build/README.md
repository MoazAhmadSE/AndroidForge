# E-Challan Checker (Android)

This Android Studio project opens the official PSCA E-Challan website in a visible WebView and fills the plate/CNIC-or-chassis fields. The user must complete the official CAPTCHA and press Search.

## Challan results and reminders
- After the PSCA results page loads, the app reads the visible `#mytable` result rows.
- It identifies the `Paid` column by its header (falling back to the observed column index 12) and treats `No`, `Unpaid`, or `Not Paid` as unpaid.
- It shows each unpaid challan number, penalty amount, and due date.
- It starts a foreground reminder service. A notification repeats every 5 minutes with the plate, unpaid count, challan numbers, and amounts.
- A persistent notification indicates that local reminders are active. Android notification permission must be granted.
- If a later manual PSCA search returns no unpaid rows, the reminder service is stopped.

## Important limitations
- This app does not bypass, solve, or automate CAPTCHA. The user must complete the official verification.
- Search is still submitted by the user on the PSCA page.
- Five-minute notifications repeat the **last successfully retrieved unpaid results**. They do not re-query PSCA every five minutes and cannot detect a later payment until the user performs another PSCA search.
- The foreground service is a best-effort way to keep a five-minute local reminder running. Android vendors may stop background services; notification permission and battery settings affect reliability.
- The app does not store the entered CNIC/chassis number. It is held in memory only for the active WebView session.
- The app only permits navigation on `echallan.psca.gop.pk`.

## Build the APK
1. Install Android Studio (current stable) on a computer.
2. Open this `echallan_project_build` folder in Android Studio.
3. Allow Android Studio to install the Android Gradle plugin and Android SDK platform 35 if prompted.
4. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. When the build completes, click **locate**. The APK will be at `app/build/outputs/apk/debug/app-debug.apk`.

## Install on your phone
1. Transfer `app-debug.apk` to your Android phone.
2. Open the APK using Files/Downloads.
3. If Android asks, allow **Install unknown apps** for the app used to open it.
4. Tap **Install**, then open **E-Challan Checker**.
5. Grant notification permission when asked.
6. Enter the plate and CNIC/chassis number, continue, complete CAPTCHA, and tap Search on the PSCA page.
7. If unpaid challans are found, the app displays them and starts five-minute reminders.

## Build/test status
This is Android Studio source code, not a compiled APK. The current environment has Java but no Android SDK or Gradle executable, so a real APK build and device test cannot be completed here. Build and test on a real Android device, especially the current PSCA table markup and Android notification behavior.
