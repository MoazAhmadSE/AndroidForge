package pk.echallan.checker;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.graphics.Color;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.List;

public class WebActivity extends Activity {
    static final String EXTRA_PLATE = "plate";
    static final String EXTRA_IDENTITY = "identity";
    private static final String OFFICIAL_HOST = "echallan.psca.gop.pk";
    private static final String OFFICIAL_URL = "https://echallan.psca.gop.pk/";
    private WebView webView;
    private String plate;
    private String identity;
    private boolean fieldsFilled = false;
    private boolean resultsHandled = false;
    private volatile boolean searchSubmitted = false;
    private final Handler handler = new Handler();

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        plate = getIntent().getStringExtra(EXTRA_PLATE);
        identity = getIntent().getStringExtra(EXTRA_IDENTITY);
        if (plate == null || identity == null) { finish(); return; }

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.WHITE);
        TextView note = new TextView(this);
        note.setText("Your details are filled on the official PSCA page. Complete its CAPTCHA and tap Search. Results will be checked for unpaid challans.");
        note.setTextColor(Color.rgb(25, 65, 49));
        note.setPadding(16, 12, 16, 12);
        root.addView(note, new LinearLayout.LayoutParams(-1, -2));
        ProgressBar progress = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        root.addView(progress, new LinearLayout.LayoutParams(-1, 5));
        webView = new WebView(this);
        root.addView(webView, new LinearLayout.LayoutParams(-1, 0, 1));
        setContentView(root);

        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setDomStorageEnabled(true);
        webView.getSettings().setJavaScriptCanOpenWindowsAutomatically(false);
        webView.addJavascriptInterface(new ResultsBridge(), "PSCAApp");
        webView.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                String host = request.getUrl().getHost();
                return host == null || !host.equalsIgnoreCase(OFFICIAL_HOST);
            }

            @Override public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                if (!isOfficialUrl(url)) return;
                if (!fieldsFilled) fillOfficialForm();
                if (searchSubmitted && !resultsHandled) scheduleResultExtraction(0);
            }
        });
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public void onProgressChanged(WebView view, int newProgress) {
                progress.setProgress(newProgress);
                progress.setVisibility(newProgress >= 100 ? View.GONE : View.VISIBLE);
            }
        });
        webView.loadUrl(OFFICIAL_URL);
    }

    private boolean isOfficialUrl(String url) {
        if (url == null) return false;
        android.net.Uri uri = android.net.Uri.parse(url);
        return "https".equalsIgnoreCase(uri.getScheme())
                && OFFICIAL_HOST.equalsIgnoreCase(uri.getHost());
    }

    private void fillOfficialForm() {
        String safePlate = JSONObject.quote(plate);
        String safeIdentity = JSONObject.quote(identity);
        String js = "(function(){" +
            "var p=document.getElementById('PlateNo');" +
            "var c=document.getElementById('OwnerCNIC');" +
            "if(!p||!c)return false;" +
            "p.value=" + safePlate + "; c.value=" + safeIdentity + ";" +
            "p.dispatchEvent(new Event('input',{bubbles:true}));" +
            "p.dispatchEvent(new Event('change',{bubbles:true}));" +
            "c.dispatchEvent(new Event('input',{bubbles:true}));" +
            "c.dispatchEvent(new Event('change',{bubbles:true}));" +
            "var b=document.getElementById('myButton');if(b&&!b.__pscaListener){b.__pscaListener=true;b.addEventListener('click',function(){if(window.PSCAApp)window.PSCAApp.onSearchStarted();});}" +
            "return true;})()";
        webView.evaluateJavascript(js, result -> {
            if ("true".equals(result)) fieldsFilled = true;
        });
    }

    private void scheduleResultExtraction(int attempt) {
        // Poll briefly because the PSCA results table may be populated after navigation.
        handler.postDelayed(() -> {
            if (webView == null || resultsHandled || !searchSubmitted) return;
            String js =
                "(function(){" +
                "var t=document.getElementById('mytable');" +
                "if(!t)return 'NO_TABLE';" +
                "var hs=Array.from(t.querySelectorAll('thead th')).map(x=>(x.innerText||x.textContent||'').trim().toLowerCase());" +
                "var idx=function(names,fallback){for(var i=0;i<hs.length;i++){if(names.indexOf(hs[i])>=0)return i;}return fallback;};" +
                "var ip=idx(['paid'],12), ic=idx(['challan no'],2), il=idx(['plate no'],3), ia=idx(['penalty'],4), id=idx(['due date'],5);" +
                "var out=[]; Array.from(t.querySelectorAll('tbody tr')).forEach(function(r){" +
                "var c=Array.from(r.cells).map(x=>(x.innerText||x.textContent||'').trim());" +
                "if(c.length){out.push({challan:c[ic]||'',plate:c[il]||'',amount:c[ia]||'',dueDate:c[id]||'',paid:c[ip]||''});}" +
                "}); return JSON.stringify(out);})()";
            webView.evaluateJavascript(js, result -> {
                if (result == null || "\"NO_TABLE\"".equals(result)) {
                    if (attempt < 20) scheduleResultExtraction(attempt + 1);
                    return;
                }
                try {
                    String decoded = result;
                    if (decoded.startsWith("\"") && decoded.endsWith("\"")) {
                        decoded = new JSONArray("[" + decoded + "]").getString(0);
                    }
                    JSONArray rows = new JSONArray(decoded);
                    if (rows.length() == 0) {
                        if (attempt < 20) scheduleResultExtraction(attempt + 1);
                        return; // Do not mistake a blocked search or empty pre-search table for a successful zero-result search.
                    }
                    resultsHandled = true;
                    handleResults(rows);
                } catch (Exception ignored) {
                    if (attempt < 20) scheduleResultExtraction(attempt + 1);
                }
            });
        }, 1000);
    }

    private void handleResults(JSONArray rows) {
        List<JSONObject> unpaid = new ArrayList<>();
        for (int i = 0; i < rows.length(); i++) {
            JSONObject row = rows.optJSONObject(i);
            if (row == null) continue;
            String paid = row.optString("paid", "").trim().toLowerCase();
            if (paid.equals("no") || paid.equals("unpaid") || paid.equals("not paid")) {
                unpaid.add(row);
            }
        }

        if (unpaid.isEmpty()) {
            stopReminderService();
            showResultDialog("No unpaid challans found",
                    rows.length() == 0 ? "The PSCA page returned no challan rows." :
                    "The retrieved challans are marked as paid. No reminders are active.");
            return;
        }

        JSONArray unpaidJson = new JSONArray(unpaid);
        Intent service = new Intent(this, ReminderService.class);
        service.setAction(ReminderService.ACTION_START);
        service.putExtra(ReminderService.EXTRA_PLATE, plate);
        service.putExtra(ReminderService.EXTRA_ROWS, unpaidJson.toString());
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(service);
        else startService(service);

        StringBuilder message = new StringBuilder();
        message.append(unpaid.size()).append(" unpaid challan(s) found:\n\n");
        for (JSONObject row : unpaid) {
            message.append("Challan: ").append(row.optString("challan", "—"))
                    .append("\nAmount: Rs. ").append(row.optString("amount", "—"))
                    .append("\nDue date: ").append(row.optString("dueDate", "—"))
                    .append("\n\n");
        }
        message.append("A reminder notification will repeat every 5 minutes using this retrieved result. Check PSCA again to refresh the payment status.");
        showResultDialog("Unpaid challans found", message.toString());
    }

    private void showResultDialog(String title, String message) {
        if (isFinishing()) return;
        new AlertDialog.Builder(this)
                .setTitle(title)
                .setMessage(message)
                .setPositiveButton("OK", null)
                .show();
    }

    private void stopReminderService() {
        Intent stop = new Intent(this, ReminderService.class);
        stop.setAction(ReminderService.ACTION_STOP);
        startService(stop);
    }

    private class ResultsBridge {
        @JavascriptInterface public void onSearchStarted() {
            searchSubmitted = true;
            handler.post(() -> scheduleResultExtraction(0));
        }
    }

    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }

    @Override protected void onDestroy() {
        handler.removeCallbacksAndMessages(null);
        if (webView != null) {
            webView.stopLoading();
            webView.removeJavascriptInterface("PSCAApp");
            webView.loadUrl("about:blank");
            webView.clearHistory();
            webView.removeAllViews();
            webView.destroy();
            webView = null;
        }
        plate = null;
        identity = null;
        super.onDestroy();
    }
}
