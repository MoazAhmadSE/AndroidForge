package pk.echallan.checker;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import org.json.JSONArray;
import org.json.JSONObject;

public class ReminderService extends Service {
    public static final String ACTION_START = "pk.echallan.checker.START_REMINDERS";
    public static final String ACTION_STOP = "pk.echallan.checker.STOP_REMINDERS";
    public static final String EXTRA_PLATE = "reminder_plate";
    public static final String EXTRA_ROWS = "reminder_rows";
    private static final String CHANNEL_ID = "unpaid_challan_reminders";
    private static final int FOREGROUND_ID = 4101;
    private static final int REMINDER_ID = 4102;
    private static final long INTERVAL_MS = 5L * 60L * 1000L;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private String plate = "";
    private String detailText = "";
    private int unpaidCount = 0;

    private final Runnable reminderTask = new Runnable() {
        @Override public void run() {
            if (unpaidCount <= 0) { stopSelf(); return; }
            showReminder();
            handler.postDelayed(this, INTERVAL_MS);
        }
    };

    @Override public void onCreate() { super.onCreate(); createChannel(); }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_STOP.equals(intent.getAction())) {
            handler.removeCallbacks(reminderTask);
            NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            nm.cancel(FOREGROUND_ID); nm.cancel(REMINDER_ID);
            stopForeground(true); stopSelf(); return START_NOT_STICKY;
        }
        if (intent != null && ACTION_START.equals(intent.getAction())) {
            plate = intent.getStringExtra(EXTRA_PLATE);
            buildDetails(intent.getStringExtra(EXTRA_ROWS));
            startForeground(FOREGROUND_ID, buildOngoingNotification());
            handler.removeCallbacks(reminderTask);
            handler.postDelayed(reminderTask, INTERVAL_MS);
        }
        return START_NOT_STICKY;
    }

    private void buildDetails(String json) {
        unpaidCount = 0;
        StringBuilder b = new StringBuilder();
        try {
            JSONArray rows = new JSONArray(json == null ? "[]" : json);
            unpaidCount = rows.length();
            for (int i = 0; i < rows.length(); i++) {
                JSONObject row = rows.optJSONObject(i);
                if (row == null) continue;
                if (b.length() > 0) b.append(" • ");
                b.append("#").append(row.optString("challan", "—"))
                 .append(" Rs ").append(row.optString("amount", "—"));
            }
        } catch (Exception ignored) { }
        detailText = b.toString();
    }

    private Notification buildOngoingNotification() {
        PendingIntent pi = openAppPendingIntent(0);
        return createNotificationBuilder()
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentTitle("Monitoring unpaid challans")
                .setContentText(unpaidCount + " unpaid challan(s) for " + plate)
                .setStyle(new Notification.BigTextStyle().bigText(detailText))
                .setContentIntent(pi)
                .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Stop reminders", stopPendingIntent())
                .setOngoing(true).build();
    }

    private void showReminder() {
        String body = "Plate: " + plate + " • " + unpaidCount + " unpaid challan(s). " + detailText;
        Notification notification = createNotificationBuilder()
                .setSmallIcon(android.R.drawable.ic_dialog_alert)
                .setContentTitle("Unpaid E-Challan reminder")
                .setContentText(body)
                .setStyle(new Notification.BigTextStyle().bigText(body))
                .setContentIntent(openAppPendingIntent(1))
                .setAutoCancel(true).setOnlyAlertOnce(false).build();
        ((NotificationManager) getSystemService(NOTIFICATION_SERVICE)).notify(REMINDER_ID, notification);
    }

    private PendingIntent stopPendingIntent() {
        Intent stop = new Intent(this, ReminderService.class);
        stop.setAction(ACTION_STOP);
        return PendingIntent.getService(this, 2, stop,
                PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0));
    }

    private PendingIntent openAppPendingIntent(int requestCode) {
        Intent open = new Intent(this, MainActivity.class);
        return PendingIntent.getActivity(this, requestCode, open,
                PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0));
    }

    private Notification.Builder createNotificationBuilder() {
        if (Build.VERSION.SDK_INT >= 26) return new Notification.Builder(this, CHANNEL_ID);
        return new Notification.Builder(this);
    }

    private void createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID,
                    "Unpaid challan reminders", NotificationManager.IMPORTANCE_HIGH);
            channel.setDescription("Repeating reminders for unpaid PSCA challans already retrieved by the app.");
            ((NotificationManager) getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(channel);
        }
    }

    @Override public void onDestroy() { handler.removeCallbacks(reminderTask); super.onDestroy(); }
    @Override public IBinder onBind(Intent intent) { return null; }
}
