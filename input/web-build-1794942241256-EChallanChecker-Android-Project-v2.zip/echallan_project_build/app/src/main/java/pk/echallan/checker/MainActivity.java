package pk.echallan.checker;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends Activity {
    private static final int REQUEST_NOTIFICATIONS = 71;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        if (Build.VERSION.SDK_INT >= 33 &&
                checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQUEST_NOTIFICATIONS);
        }
        EditText plate = findViewById(R.id.plateInput);
        EditText identity = findViewById(R.id.identityInput);
        Button check = findViewById(R.id.checkButton);
        check.setOnClickListener(v -> {
            String plateValue = plate.getText().toString().trim();
            String identityValue = identity.getText().toString().trim();
            if (plateValue.isEmpty()) { plate.setError("Enter your vehicle plate number"); plate.requestFocus(); return; }
            if (identityValue.isEmpty()) { identity.setError("Enter your CNIC or chassis number"); identity.requestFocus(); return; }
            Intent intent = new Intent(this, WebActivity.class);
            intent.putExtra(WebActivity.EXTRA_PLATE, plateValue);
            intent.putExtra(WebActivity.EXTRA_IDENTITY, identityValue);
            startActivity(intent);
        });
    }
}
