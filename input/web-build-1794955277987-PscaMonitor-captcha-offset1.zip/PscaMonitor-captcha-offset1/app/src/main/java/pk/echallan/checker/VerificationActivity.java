package pk.echallan.checker;

import android.os.Bundle;
import android.view.ViewGroup;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import androidx.appcompat.app.AppCompatActivity;
import org.json.JSONObject;
import pk.echallan.checker.db.AppDatabase;
import pk.echallan.checker.db.Challan;
import pk.echallan.checker.db.Vehicle;
import pk.echallan.checker.monitor.ChangeDetector;
import pk.echallan.checker.monitor.ResultParser;
import pk.echallan.checker.security.Crypto;

public class VerificationActivity extends AppCompatActivity {
    private long vehicleId;
    private WebView web;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        vehicleId = getIntent().getLongExtra("vehicleId", -1);
        if (vehicleId <= 0) { finish(); return; }

        FrameLayout root = new FrameLayout(this);
        web = new WebView(this);
        root.addView(web, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        setContentView(root);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        web.setWebViewClient(new WebViewClient());

        AppDatabase.io().execute(() -> {
            Vehicle v = AppDatabase.get(this).vehicleDao().byId(vehicleId);
            String cnic = v == null ? null : Crypto.decrypt(v.cnicEnc);
            runOnUiThread(() -> {
                if (v == null || cnic == null) { finish(); return; }
                web.loadUrl("https://echallan.psca.gop.pk/");
                web.setWebViewClient(new WebViewClient() {
                    @Override public void onPageFinished(WebView view, String url) {
                        view.evaluateJavascript(
                                "window.__psca_plate=" + JSONObject.quote(v.plateNo)
                                + ";window.__psca_cnic=" + JSONObject.quote(cnic) + ";", null);
                        view.evaluateJavascript(JS_BOOT_VISIBLE, null);
                        view.evaluateJavascript(JS_PARSE_VISIBLE, null);
                        pollResults(v);
                    }
                });
            });
        });
    }

    private void pollResults(Vehicle v) {
        web.postDelayed(new Runnable() {
            @Override public void run() {
                web.evaluateJavascript("(function(){if(!window.__psca)return 'null';return JSON.stringify(window.__psca);})()",
                        raw -> {
                            try {
                                String j = raw == null ? null : raw.trim();
                                if (j != null && j.startsWith("\"")) {
                                    j = new JSONObject("{\"v\":" + j + "}").getString("v");
                                }
                                if (j != null && !"null".equals(j)) {
                                    JSONObject o = new JSONObject(j);
                                    String st = o.optString("state", "");
                                    if ("token_ready".equals(st)) {
                                        web.evaluateJavascript(
                                                "(function(){var t=document.querySelector('input[name=\\\"cap-token\\\"]');"
                                                + "if(!t||!t.value)return;var f=t.closest('form')||document.querySelector('form');"
                                                + "if(!f)return;var b=f.querySelector('button[type=\\\"submit\\\"],input[type=\\\"submit\\\"],button.btn-primary');"
                                                + "if(b){b.click();}else{f.submit();}window.__psca.state='submitted';})();", null);
                                    } else if ("results".equals(st)) {
                                        org.json.JSONObject d = o.optJSONObject("data");
                                        if (d != null) {
                                            java.util.List<Challan> parsed = new java.util.ArrayList<>();
                                            org.json.JSONArray arr = d.optJSONArray("items");
                                            if (arr != null) for (int i = 0; i < arr.length(); i++) {
                                                Challan c = ResultParser.toChallan(v.id, v.plateNo, arr.optJSONObject(i));
                                                if (c != null) parsed.add(c);
                                            }
                                            AppDatabase.io().execute(() -> {
                                                AppDatabase db = AppDatabase.get(VerificationActivity.this);
                                                ChangeDetector.apply(db, VerificationActivity.this, v, parsed);
                                                db.vehicleDao().markResult(
                                                        v.id, System.currentTimeMillis(), "OK", null);
                                                VerificationActivity.this.runOnUiThread(
                                                        () -> VerificationActivity.this.finish());
                                            });
                                            return;
                                        }
                                    }
                                }
                            } catch (Exception ignored) {}
                            web.postDelayed(this, 900);
                        });
            }
        }, 900);
    }

    private static final String JS_BOOT_VISIBLE = """
(function(){
  window.__psca = window.__psca || {};
  window.__psca.state = 'loading';
  function q(s){return document.querySelector(s);}
  var plate = q('input[name="PlateNo"],#PlateNo,input[id*="Plate" i],input[placeholder*="Plate" i],input[placeholder*="Vehicle" i]');
  var cnic  = q('input[name="OwnerCNIC"],#OwnerCNIC,#CNIC,input[name="cnic"],input[id*="CNIC" i],input[placeholder*="CNIC" i]');
  if (plate && cnic) {
    plate.value = window.__psca_plate || '';
    cnic.value  = window.__psca_cnic  || '';
    ['input','change','blur'].forEach(function(ev){plate.dispatchEvent(new Event(ev,{bubbles:true}));cnic.dispatchEvent(new Event(ev,{bubbles:true}));});
    window.__psca.state = 'form_filled';
  }
  var t0 = Date.now();
  var timer = setInterval(function(){
    var cap = q('cap-widget');
    if (cap) {
      // Read-only CAPTCHA checkbox geometry for diagnostics; does not click or solve CAPTCHA.
      try {
        var sr = cap.shadowRoot;
        var checkbox = sr && sr.querySelector('.checkbox');
        var widget = sr && sr.querySelector('.captcha');
        if (checkbox && widget) {
          var cr = checkbox.getBoundingClientRect();
          var wr = widget.getBoundingClientRect();
          window.__psca.captchaCheckboxOffset = {
            x: cr.left + window.scrollX,
            y: cr.top + window.scrollY,
            viewportX: cr.left,
            viewportY: cr.top,
            centerX: cr.left + cr.width / 2 + window.scrollX,
            centerY: cr.top + cr.height / 2 + window.scrollY,
            width: cr.width,
            height: cr.height,
            relativeX: cr.left - wr.left,
            relativeY: cr.top - wr.top
          };
        }
      } catch (e) {}
      var root = cap.shadowRoot;
      var w = root && root.querySelector('.captcha');
      var st = w && w.getAttribute('data-state');
      if (st === 'done') {
        var ti = cap.querySelector('input[name="cap-token"]');
        if (ti && ti.value) { window.__psca.state = 'token_ready'; clearInterval(timer); return; }
      }
      if (st === 'error') { window.__psca.state = 'cap_error'; clearInterval(timer); return; }
      if (window.__psca.state === 'form_filled') window.__psca.state = 'awaiting_cap';
    }
    if (Date.now() - t0 > 300000) clearInterval(timer);
  }, 700);
})();
""";

    private static final String JS_PARSE_VISIBLE = """
(function(){
  if (!window.__psca) window.__psca = {};
  if (window.__psca.data) return;
  var best=null, bestRows=0, tables=document.querySelectorAll('table');
  for (var i=0;i<tables.length;i++){var rs=tables[i].querySelectorAll('tbody tr');if(rs.length>bestRows){best=tables[i];bestRows=rs.length;}}
  if (best && bestRows>0){
    var headers=[],ths=best.querySelectorAll('thead th');
    for (var j=0;j<ths.length;j++) headers.push((ths[j].innerText||'').trim().toLowerCase());
    var items=[],rows=best.querySelectorAll('tbody tr');
    for (var k=0;k<rows.length;k++){
      var tds=rows[k].querySelectorAll('td'); if(tds.length<3) continue;
      var o={},cells=[];
      for (var m=0;m<tds.length;m++){var txt=(tds[m].innerText||'').trim();cells.push(txt);if(headers[m])o[headers[m]]=txt;}
      o['__cells']=cells;items.push(o);
    }
    window.__psca.data={empty:false,items:items};window.__psca.state='results';return;
  }
  var body=((document.body&&document.body.innerText)||'').toLowerCase();
  if (body.indexOf('no record')>=0||body.indexOf('no challan')>=0||body.indexOf('not found')>=0){
    window.__psca.data={empty:true,items:[]};window.__psca.state='results';
  }
})();
""";
private static final String JS_ZIGZAG_CLICK = """
(function(){
  var cap = document.querySelector('cap-widget');
  if (!cap) return;
  var sr = cap.shadowRoot;
  var checkbox = sr && sr.querySelector('.checkbox');
  if (!checkbox) return;

  var cr = checkbox.getBoundingClientRect();
  var x0 = window.scrollX;
  var y0 = window.scrollY;
  var x1 = cr.left + window.scrollX;
  var y1 = cr.top + window.scrollY;
  var dx = x1 - x0;
  var dy = y1 - y0;
  var steps = Math.max(Math.abs(dx), Math.abs(dy));
  var zigzagStep = 0;

  function moveCursor() {
    var t = Date.now();
    var progress = t / 2000; // Move over 2 seconds
    if (progress > 1) progress = 1;

    // Zigzag pattern
    var zigzagOffsetX = Math.sin(zigzagStep * Math.PI / 180) * (cr.width / 2);
    zigzagStep += 10; // Adjust for speed

    var x = x0 + dx * progress + zigzagOffsetX;
    var y = y0 + dy * progress;

    // Simulate mouse movement
    try {
      document.dispatchEvent(new MouseEvent('mousemove', {
        bubbles: true,
        cancelable: true,
        clientX: x,
        clientY: y,
        view: window
      }));
    } catch (e) {}

    if (progress < 1) {
      requestAnimationFrame(moveCursor);
    } else {
      // Simulate click
      try {
        checkbox.dispatchEvent(new MouseEvent('click', {
          bubbles: true,
          cancelable: true,
          view: window
        }));
      } catch (e) {}
    }
  }

  moveCursor();
})();
""";

}
